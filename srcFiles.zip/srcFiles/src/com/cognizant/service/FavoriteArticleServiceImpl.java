package com.cognizant.service;

import java.util.Iterator;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.FavoriteArticleDao;
import com.cognizant.entity.FavoriteArticle;
@Service
public class FavoriteArticleServiceImpl implements FavoriteArticleService {
	
	@Autowired
	private FavoriteArticleDao favoriteArticleDao;
	
	@Override
	public FavoriteArticle save(FavoriteArticle favoriteArticle) {
		return favoriteArticleDao.save(favoriteArticle);
	}

	@Override
	public void delete(FavoriteArticle favoriteArticle) {
		favoriteArticleDao.delete(favoriteArticle);
	}

	@Override
	public void deleteFavoriteArticle(int favoriteArticleId) {
		favoriteArticleDao.deleteFavoriteArticle(favoriteArticleId);
		/*try{
			SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
			Session session = sessionFactory.openSession();
			Query query = session.createSQLQuery("DELETE FROM Favorite_Article WHERE fav_Article_Id = :favArticleId");
			query.setParameter("favArticleId", favoriteArticleId);
			Transaction tx = session.beginTransaction();
			
			query.executeUpdate();
			tx.commit();
			

			}catch(HibernateException e){
				System.out.println("Record couldn't be deleted..." + e.getMessage());
			}*/
	}
}