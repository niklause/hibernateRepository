package com.cognizant.service;

import com.cognizant.entity.FavoriteArticle;

public interface FavoriteArticleService {
	FavoriteArticle save(FavoriteArticle favoriteArticle);
	void delete(FavoriteArticle favoriteArticle);
	void deleteFavoriteArticle(int favArticleId);
}