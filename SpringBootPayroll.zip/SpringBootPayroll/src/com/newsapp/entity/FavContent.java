/**
 * 
 */
package com.newsapp.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author 770106
 *
 */
@Entity
@Table(name="favContent")
public class FavContent implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7876973536152985454L;
	@ManyToOne(cascade=CascadeType.ALL)
	private User userName;
	@Column(name="favContent")
	private String contentUrl;
	public User getUserName() {
		return userName;
	}
	public void setUserName(User userName) {
		this.userName = userName;
	}
	public String getContentUrl() {
		return contentUrl;
	}
	public void setContentUrl(String contentUrl) {
		this.contentUrl = contentUrl;
	}
	

}
