/**
 * 
 */
package com.newsapp.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Table;

import org.hibernate.annotations.Entity;

/**
 * @author 770106
 *
 */
@Entity
@Table(name="Admin")
public class Admin implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 257065836159005522L;
	@Column(name="admin_name",nullable = false)
	private String adminUsername;
	@Column(name="password",nullable = false)
	private String adminPassword;
	public String getAdminUsername() {
		return adminUsername;
	}
	public void setAdminUsername(String adminUsername) {
		this.adminUsername = adminUsername;
	}
	public String getAdminPassword() {
		return adminPassword;
	}
	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}
	
	
	

}
