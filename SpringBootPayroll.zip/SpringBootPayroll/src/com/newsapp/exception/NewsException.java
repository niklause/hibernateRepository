/**
 * 
 */
package com.newsapp.exception;

/**
 * @author 770106
 *
 */
public class NewsException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 155523434506181395L;
	public NewsException() {
		
	}	
	public NewsException(String message) {
		super(message);
	}

}
