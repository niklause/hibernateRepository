package com.newsapp.dao;
import com.newsapp.entity.User;
import com.newsapp.exception.NewsException;
public interface IAdminDao
{
	public User searchIdbyUsername(final String username) throws NewsException;

}
