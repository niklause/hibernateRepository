/**
 * 
 */
package com.newsapp.dao;

import com.newsapp.entity.FavContent;
import com.newsapp.entity.User;
import com.newsapp.exception.NewsException;

/**
 * @author 770106
 *
 */
public class UserDaoImpl implements IuserDao {

	@Override
	public User validateUser(String userName, String password) throws NewsException {
		return null;
	}

	@Override
	public int registerUser(User user) throws NewsException {
		return 0;
	}

	@Override
	public int addFavArticle(FavContent content) throws NewsException {
		return 0;
	}

	@Override
	public int deleteFavArticle(FavContent content) throws NewsException {
		return 0;
	}

}
