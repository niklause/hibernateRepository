/**
 * 
 */
package com.newsapp.dao;

import com.newsapp.entity.User;
import com.newsapp.exception.NewsException;

/**
 * @author 770106
 *
 */
public class AdminDaoImpl implements IAdminDao {

	@Override
	public User searchIdbyUsername(String username) throws NewsException {
		// TODO Auto-generated method stub
		return null;
	}

}
