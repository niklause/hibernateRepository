package com.newsapp.dao;

import com.newsapp.entity.FavContent;
import com.newsapp.entity.User;
import com.newsapp.exception.NewsException;
public interface IuserDao {
	public User validateUser(final String userName,final String password) throws NewsException ;
    public int registerUser(final User user) throws NewsException;
    public int addFavArticle(final FavContent content) throws NewsException;
    public int deleteFavArticle(final FavContent content) throws NewsException;
}
